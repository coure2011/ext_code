<script lang="ts">
import $ from 'jquery';
import 'devextreme/integration/jquery';
import 'devextreme/ui/data_grid';

export default({
  data() {
    return {
      msg: 'Hello there!',
    }
  },
  mounted() {
    $('#testIt').dxDataGrid({
      dataSource: [
        {
          test1: '1',
          test2: '2',
        },
        {
          test1: '3',
          test2: '4',
        },
        {
          test1: '5',
          test2: '6',
        },
      ],
      columns: [
        {
          dataField: 'test1'
        },
        {
          dataField: 'test2'
        },
      ]
    });
  }
})
</script>

<template>
  <div class="greetings">
    <h1>My Grid</h1>
    <div id="testIt" />
  </div>
</template>

<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    display: block;
    text-align: left;
  }
}
</style>
