/// <reference types="vite/client" />
/// <reference types="unplugin-vue2-script-setup/shims" />
